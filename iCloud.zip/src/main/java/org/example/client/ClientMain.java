package org.example.client;

public class ClientMain {
    public static void main(String[] args) {
        new ClientApplication().run();
    }
}
