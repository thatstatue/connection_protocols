package org.example;

public enum Connection {
    available , verified
}
