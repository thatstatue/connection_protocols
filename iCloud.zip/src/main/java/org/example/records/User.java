package org.example.records;

public record User(String username, String hashedPassword) {
}
