package org.example.records;

public record TransferInfo( int ping , int bandwidth) {
}
