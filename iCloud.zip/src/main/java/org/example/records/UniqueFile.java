package org.example.records;

public record UniqueFile(byte[] data, String id) {
}
