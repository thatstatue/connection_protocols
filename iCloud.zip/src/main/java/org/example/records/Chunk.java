package org.example.records;

public record Chunk(int chunkSize, int totalChunks) {
}
