package org.example.server;

public enum AccountState {
    signedIn, guest
}
