package org.example.server;

public class ServerMain {
    public static void main(String[] args) {
        new ServerApplication().run();
    }
}
